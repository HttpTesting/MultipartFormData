from MultipartFormData.Multipart import MultipartFormData

format_str = MultipartFormData.to_form_data(data, headers={})